from setuptools import setup

setup(
    name='doc_builder_ebrl',
    version='0.1',
    scripts=['main.py'],
    install_requires=['PyCap','python-docx','argparse']
)
